document.addEventListener('DOMContentLoaded', function() {
    // Inicializar animaciones
    const elementosAnimados = document.querySelectorAll('[data-animacion]');
    elementosAnimados.forEach(elem => {
        elem.style.opacity = '0';
        elem.style.animation = 'none';
        setTimeout(() => {
            elem.style.opacity = '1';
            elem.style.animation = '';
        }, 100);
    });

    // Cargar tema
    cargarTema();

    // Agregar funcionalidad de menú responsive
    const menuToggle = document.createElement('button');
    menuToggle.textContent = 'Menú';
    menuToggle.classList.add('menu-toggle');
    document.querySelector('.menu').prepend(menuToggle);

    menuToggle.addEventListener('click', function() {
        document.querySelector('.menu ul').classList.toggle('mostrar');
    });
});

// Función para cambiar tema
function cambiarTema(tema) {
    document.documentElement.setAttribute('data-tema', tema);
    localStorage.setItem('tema', tema);
}

// Función para cargar el tema guardado
function cargarTema() {
    const temaGuardado = localStorage.getItem('tema');
    if (temaGuardado) {
        cambiarTema(temaGuardado);
    }
}